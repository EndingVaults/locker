<div align="center">
    <h1>Self Streaming Status</h1>
</div>

----

### Vote for us! (Please)


### **How to use?**
- Download the repo, rename `example-config.json` file to `config.json` file, and add your `token` into it.
- Do `npm install` than `node .` to running codes
### **Glitch Hosting**
- [Click here to remix](https://glitch.com/edit/#!/remix/streaming-bot-status)
- `.env` file put 
```json
TOKEN=paste-token-here
```
### **How to get self Token?**
- [Click here](https://github.com/Tyrrrz/DiscordChatExporter/wiki/Obtaining-Token-and-Channel-IDs)

### Support
 - https://discord.gg/e5u77TSCKY

### Requirements
 - Node `12.x+`
 - `discord.js-selfbot-v11` npm

### Self-streaming-status
<!-- [![Discord Server](https://discordapp.com/api/guilds/625977459845890049/embed.png)](https://discord.gg/ZG3UCB5) -->
[![Build With](https://img.shields.io/npm/v/discord.js.svg?maxAge=3600)](https://www.npmjs.com/package/discord.js)

----
